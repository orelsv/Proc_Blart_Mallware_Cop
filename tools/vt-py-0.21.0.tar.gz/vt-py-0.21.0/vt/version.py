"""Defines VT release version."""

__version__ = "0.21.0"
